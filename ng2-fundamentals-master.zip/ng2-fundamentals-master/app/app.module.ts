import { NgModule } from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import{RouterModule} from '@angular/router';
import { EventsAppComponent } from './events-app.component';
import { AuthenticateService } from './User/authenticate.service';
import {NavBarComponent} from './Nav/nav.component';

import{appRoutes} from './routes';
import { Error404Component } from './errors/404.component';
import{EventsListComponent, EventsThumbnailComponent,
    EventService,EventDetailComponent,
    CreateEventComponent, EventRouteActivatorService
,EventListResolver,CreateSessionComponent,
SessionListComponent,DurationPipe
} from './events/index';

import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import {CollapsibleWellComponent,TOASTR_TOKEN,Toastr,
    JQ_TOKEN,SimpleModelComponent,ModelTriggerDirective } from './Common/index';

declare let toastr:Toastr;
declare let jQuery:Object;

@NgModule
({
    
    imports:[BrowserModule,
        FormsModule,
        ReactiveFormsModule,
    RouterModule.forRoot(appRoutes)
    ],
    declarations:[EventsAppComponent,
        EventsListComponent,
        EventsThumbnailComponent,
        NavBarComponent,
        EventDetailComponent,
    CreateEventComponent,
    Error404Component,CreateSessionComponent,SessionListComponent,CollapsibleWellComponent,
    SimpleModelComponent,
    ModelTriggerDirective,
    DurationPipe
    ],
        
providers:[
    EventService,
    AuthenticateService, 
      {    provide:TOASTR_TOKEN, useValue: toastr    },
      {    provide:JQ_TOKEN, useValue: jQuery    },
    EventRouteActivatorService,
    EventListResolver,
   {
       provide:'canDeactivateCreateEvent' ,
       useValue:checkDirtyState
    }  
],
bootstrap:[EventsAppComponent]

})
export class AppModule{}
function checkDirtyState(component:CreateEventComponent)
{
    if(component.isDirty) 
    return window.confirm('You have not saved this event! Do you really want to cancel?')
return true

}