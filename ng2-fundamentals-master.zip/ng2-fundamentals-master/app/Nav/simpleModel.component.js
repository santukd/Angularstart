"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var SimpleModelComponent = (function () {
    function SimpleModelComponent() {
    }
    return SimpleModelComponent;
}());
SimpleModelComponent = __decorate([
    core_1.Component({
        selector: 'imple-model',
        template: "\n    <div id=\"simple-model\" class=\"model fade\" tabindex=\"-1\">\n    <div class=\"model-dialog\">\n    <div class=\"model-content\">\n    <div class=\"model-header\">\n    <button type=\"button\" class=\"close\" data-dismiss=\"modal\">\n    <span> &times;<span></button>\n    <h4 class=\"modal-title\">{{title}}</h4>\n    </div>\n    <div class=\"modal.body\">\n    <ng-content></ng-content>\n       </div>\n    </div> </div> </div>\n    ",
        styles: ["\n    .model-body {height:250px;overflow-y:scroll;}\n    "]
    }),
    __metadata("design:paramtypes", [])
], SimpleModelComponent);
exports.SimpleModelComponent = SimpleModelComponent;
//# sourceMappingURL=simpleModel.component.js.map