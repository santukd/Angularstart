import { Component } from '@angular/core';
import { AuthenticateService } from '../User/authenticate.service';
import { ISession } from '../events';
import {EventService} from '../events/index'
//import {SimpleModelComponent} from '../Common/simpleModel.component'

@Component({
    selector:'Nav-Bar',
    templateUrl:'./app/Nav/nav.component.html',
    styles:[`
    .nav.bavbar-nav{font-size:15px;}
    #searchForm {margin-right:100px;}
    @media (max-widh:1200px){#searchForm {display:  mone}}
    `]

})
export class NavBarComponent{
searchTerm:string="";
foundSessions:ISession[]

    constructor (private auth : AuthenticateService,private eventService : EventService)
    {
        
console.log(this.auth.currentUser)
    }
    
    searchSessions(searchTerm)
    {

      
    this.eventService.searchSession(searchTerm).subscribe
    (session=>{
        this.foundSessions=session;
//console.log(this.foundSessions);
    });
    }
}