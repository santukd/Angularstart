import { Component,Input,Output ,EventEmitter} from "@angular/core";
import { IEvent } from "./Shared/index";


@Component
({
    
    selector:'event-thumbnail',
    template:`
   <hr><h2></h2>    
    <div [routerLink]="['/events',inputevent.id]" class ="well hoverwell thumbnail"> 
    <div>{{inputevent.name|uppercase}}</div>
    <div>Date : {{inputevent.date|date:'shortDate'}}</div>
    <div  [ngSwitch]="inputevent?.time">Time : {{inputevent.time}}
    
    <span *ngSwitchCase="'8:00 am'">Early start</span>
    <span *ngSwitchCase="'10:00 am'">Late start</span>
    <span *ngSwitchDefault>Normal start</span>
    </div>
    <div>Price : {{inputevent.price|currency:'USD':'true'}}</div>
  
    <div *ngIf="inputevent?.location">Location : <span>{{inputevent.location.address}}</span>
    <span>&nbsp;</span>
    <span>{{inputevent.location.city}}</span>
    <span>&nbsp;</span>
    <span>{{inputevent.location.country}}</span>
    </div>
    <div  *ngIf="inputevent?.OnlineUrl"> onlineurl:{{inputevent.OnlineUrl}}</div>
    
  
    </div>
   
    `,
    styles:[`
        .thumbnail {min-height:150px;}
        .pad.left {margin-left:10px;}
        .well div {color:#bbb;}
        
        `
    ]

})
export class EventsThumbnailComponent {
    @Input() inputevent :IEvent//inputevent:any
    
    
    
}
