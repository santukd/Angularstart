"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var EventsThumbnailComponent = (function () {
    function EventsThumbnailComponent() {
    }
    return EventsThumbnailComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], EventsThumbnailComponent.prototype, "inputevent", void 0);
EventsThumbnailComponent = __decorate([
    core_1.Component({
        selector: 'event-thumbnail',
        template: "\n   <hr><h2></h2>    \n    <div [routerLink]=\"['/events',inputevent.id]\" class =\"well hoverwell thumbnail\"> \n    <div>{{inputevent.name|uppercase}}</div>\n    <div>Date : {{inputevent.date|date:'shortDate'}}</div>\n    <div  [ngSwitch]=\"inputevent?.time\">Time : {{inputevent.time}}\n    \n    <span *ngSwitchCase=\"'8:00 am'\">Early start</span>\n    <span *ngSwitchCase=\"'10:00 am'\">Late start</span>\n    <span *ngSwitchDefault>Normal start</span>\n    </div>\n    <div>Price : {{inputevent.price|currency:'USD':'true'}}</div>\n  \n    <div *ngIf=\"inputevent?.location\">Location : <span>{{inputevent.location.address}}</span>\n    <span>&nbsp;</span>\n    <span>{{inputevent.location.city}}</span>\n    <span>&nbsp;</span>\n    <span>{{inputevent.location.country}}</span>\n    </div>\n    <div  *ngIf=\"inputevent?.OnlineUrl\"> onlineurl:{{inputevent.OnlineUrl}}</div>\n    \n  \n    </div>\n   \n    ",
        styles: ["\n        .thumbnail {min-height:150px;}\n        .pad.left {margin-left:10px;}\n        .well div {color:#bbb;}\n        \n        "
        ]
    }),
    __metadata("design:paramtypes", [])
], EventsThumbnailComponent);
exports.EventsThumbnailComponent = EventsThumbnailComponent;
//# sourceMappingURL=events-thumbnail.component.js.map