import { Component,OnInit, Output, EventEmitter } from "@angular/core";
import { FormControl, Validators, FormGroup } from "@angular/forms";
import { ISession } from "../Shared/index";


@Component({

selector:'create-session',
    templateUrl:'app/events/event-details/create-session.component.html',
    styles:
    [`
    em{float:right;color:#E05C65;padding-left:10px;}
 .error input,.error select,.error textarea {background-color:#E3C3C5;}
 .error ::-webkit-input-placeholder {color:#999;}
 .error::-moz-placeholder {color:#999;}
 .error:-moz-placeholder {color:#999;}
 .error::ms-input-placeholder {color:#999;}
    `]
})

export class CreateSessionComponent implements OnInit
{
    @Output() saveNewSession= new EventEmitter()


    newSessionForm:FormGroup

    name:FormControl
    presenter:FormControl
    duration:FormControl
    level:FormControl
    abstract:FormControl
   
    ngOnInit()
    {
    let name= new FormControl('',Validators.required)
    let presenter= new FormControl('',Validators.required)
    let duration= new FormControl('',Validators.required)
    let level= new FormControl('',Validators.required)
    let abstract= new FormControl('',[Validators.required,Validators.maxLength(400)])

        this.newSessionForm =new FormGroup({
    name:name,
    presenter:presenter,
    duration:duration,
    level:level,
    abstract:abstract
})

    }
  
      saveSession(formvalues)
    {
    
    let session:ISession={
        id:undefined,
        name:formvalues.name,
presenter:formvalues.presenter,
duration:formvalues.duration,
level:formvalues.level,
abstract:formvalues.abstract,
voters:[]

    }
    //console.log(session)
    this.saveNewSession.emit(session)
    }

}