"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
__export(require("./event-detail.component"));
__export(require("./event-route-activator.service"));
__export(require("./create-session.component"));
__export(require("./session-list.component"));
//# sourceMappingURL=index.js.map