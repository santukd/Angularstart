"use strict";
//# sourceMappingURL=event.model.js.map