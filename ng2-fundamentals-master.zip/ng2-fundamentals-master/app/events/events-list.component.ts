import { Component, OnInit } from '@angular/core';
import { EventService } from './Shared/event.service';
//import {ToastrService} from '../Common/toastr.service';
import { ActivatedRoute } from '@angular/router';
import { IEvent } from './Shared/index';

@Component
({
    
   
    template:`
    <div><h2>Upcomming Angular events</h2>
   <div class="row">
   <div *ngFor ="let event1 of events" class="col-md-5">
     
    <event-thumbnail    [inputevent]="event1"></event-thumbnail>
    </div>
    </div>
    `
})
export class EventsListComponent implements OnInit
{
    
   // events:any
   events:IEvent[]
  /*  constructor(  private eventService : EventService,private tostrService:ToastrService
    ,private route:ActivatedRoute)*/

    constructor(  private eventService : EventService
        ,private route:ActivatedRoute)
{

}
ngOnInit()
{
 //this.eventService.getEvents().subscribe(events=>{this.events=events});
 this.events=this.route.snapshot.data['events']
}
/*LoadToastrMessage(eventName)
{
    this.tostrService.success(eventName);
}*/
}