import {Component} from '@angular/core';
@Component
({
selector:'events-app',
template:`
<Nav-Bar></Nav-Bar>

<router-outlet></router-outlet>
`
})

export class EventsAppComponent{}