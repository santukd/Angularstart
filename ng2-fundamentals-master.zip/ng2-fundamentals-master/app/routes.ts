import{Routes} from '@angular/router';
import { Error404Component } from './errors/404.component';

import{EventsListComponent, EventDetailComponent,
    CreateEventComponent,EventRouteActivatorService,
    EventListResolver,
    CreateSessionComponent
} from './events/index'

//import { EventsListComponent } from "./events/events-list.component";
//import { EventDetailComponent } from "./events/event-details/event-detail.component";
//import { CreateEventComponent } from './events/create-event.component';
//import {EventRouteActivatorService} from './events/event-details/event-route-activator.service'
//import { EventListResolver } from './events/event-list-resolve.service';

export const appRoutes:Routes=[
{path:'events/new',component:CreateEventComponent,
canDeactivate :['canDeactivateCreateEvent']},
    {path:'events', component  : EventsListComponent,resolve:{events:EventListResolver}},
    {path:'events/:id', component : EventDetailComponent,canActivate: [EventRouteActivatorService]},
    {path:'events/session/new', component:CreateSessionComponent},
    {path:'404', component : Error404Component},
    {path:'',redirectTo:'/events',pathMatch:'full'},
    {path:'user',loadChildren:'app/user/user.module#UserModule'}
]
